<?php
/**
 * Field group model.
 *
 * @package WPCMB
 */

declare( strict_types=1 );

namespace WPCMB\Fields;

defined( 'ABSPATH' ) || exit;

/**
 * A field group: title, fields, location rules and display settings.
 *
 * Immutable value object built from the JSON stored in the group's
 * `_wpcmb_config` meta. sanitize() is the trust boundary for anything that
 * arrives from a request; nothing else in the plugin re-validates the shape.
 */
final class FieldGroup {

	/**
	 * Post id backing this group, 0 for an unsaved group.
	 *
	 * @var int
	 */
	public readonly int $id;

	/**
	 * Stable group key, e.g. `group_6a1f...`.
	 *
	 * @var string
	 */
	public readonly string $key;

	/**
	 * Human readable title.
	 *
	 * @var string
	 */
	public readonly string $title;

	/**
	 * Field definitions.
	 *
	 * @var array<int, array<string, mixed>>
	 */
	public readonly array $fields;

	/**
	 * Location rules: an OR list of AND groups.
	 *
	 * @var array<int, array<int, array{param: string, operator: string, value: string}>>
	 */
	public readonly array $location;

	/**
	 * Display settings.
	 *
	 * @var array<string, mixed>
	 */
	public readonly array $settings;

	/**
	 * Constructor.
	 *
	 * @param int                              $id       Post id.
	 * @param string                           $key      Group key.
	 * @param string                           $title    Title.
	 * @param array<int, array<string, mixed>> $fields   Field definitions.
	 * @param array<int, array<int, array>>    $location Location rules.
	 * @param array<string, mixed>             $settings Display settings.
	 */
	public function __construct(
		int $id = 0,
		string $key = '',
		string $title = '',
		array $fields = array(),
		array $location = array(),
		array $settings = array()
	) {
		$this->id       = $id;
		$this->key      = '' !== $key ? $key : self::generate_key( 'group' );
		$this->title    = $title;
		$this->fields   = $fields;
		$this->location = $location;
		$this->settings = $settings + self::default_settings();
	}

	/**
	 * Default display settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function default_settings(): array {
		return array(
			'active'                => true,
			'position'              => 'normal',
			'style'                 => 'default',
			'label_placement'       => 'top',
			'instruction_placement' => 'field',
			'menu_order'            => 0,
			'description'           => '',
			'display_title'         => '',
			'show_in_rest'          => true,
			'hide_on_screen'        => array(),

			// Only read when a location rule names an options page. Kept with
			// the group rather than in a separate store because the group is
			// what asks for the page to exist in the first place.
			'options_capability'    => 'manage_options',
			'options_icon'          => '',
			'options_parent'        => '',
			'block_enabled'         => false,
			'block_name'            => '',
			'block_icon'            => '',
			'block_category'        => '',
			'block_description'     => '',
			'block_keywords'        => '',
			'block_mode'            => 'auto',
			'block_supports'        => array(),
			'block_inner_blocks'    => false,
		);
	}

	/**
	 * Build a group from a post and its stored configuration.
	 *
	 * @param \WP_Post $post Field group post.
	 */
	public static function from_post( \WP_Post $post ): self {
		$raw    = get_post_meta( $post->ID, \WPCMB\PostTypes\FieldGroupPostType::META_CONFIG, true );
		$config = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : array();
		$config = is_array( $config ) ? $config : array();

		$config['title'] = $post->post_title;
		$config['id']    = $post->ID;

		// Active state is the post status, so the list table's publish/draft
		// controls and the editor's toggle can never disagree.
		$settings           = isset( $config['settings'] ) && is_array( $config['settings'] ) ? $config['settings'] : array();
		$settings['active'] = 'publish' === $post->post_status;
		$config['settings'] = $settings;

		return self::from_array( $config );
	}

	/**
	 * Build a group from an already-sanitized array.
	 *
	 * @param array<string, mixed> $config Group configuration.
	 */
	public static function from_array( array $config ): self {
		return new self(
			(int) ( $config['id'] ?? 0 ),
			(string) ( $config['key'] ?? '' ),
			(string) ( $config['title'] ?? '' ),
			isset( $config['fields'] ) && is_array( $config['fields'] ) ? $config['fields'] : array(),
			isset( $config['location'] ) && is_array( $config['location'] ) ? $config['location'] : array(),
			isset( $config['settings'] ) && is_array( $config['settings'] ) ? $config['settings'] : array()
		);
	}

	/**
	 * Export as a plain array, suitable for json_encode().
	 *
	 * @return array<string, mixed>
	 */
	public function to_array(): array {
		return array(
			'key'      => $this->key,
			'title'    => $this->title,
			'fields'   => $this->fields,
			'location' => $this->location,
			'settings' => $this->settings,
		);
	}

	/**
	 * Whether the group is active.
	 */
	public function is_active(): bool {
		return (bool) ( $this->settings['active'] ?? true );
	}

	/**
	 * Return a copy with different fields.
	 *
	 * @param array<int, array<string, mixed>> $fields Field definitions.
	 */
	public function with_fields( array $fields ): self {
		return new self( $this->id, $this->key, $this->title, $fields, $this->location, $this->settings );
	}

	/**
	 * Generate a collision-resistant key.
	 *
	 * @param string $prefix Key prefix, e.g. `group` or `field`.
	 */
	public static function generate_key( string $prefix ): string {
		return $prefix . '_' . substr( md5( uniqid( $prefix, true ) ), 0, 13 );
	}

	/**
	 * Sanitize untrusted group configuration.
	 *
	 * Everything that reaches storage passes through here: unknown keys are
	 * dropped rather than escaped, so the stored shape is always known.
	 *
	 * @param array<string, mixed> $raw Untrusted configuration.
	 *
	 * @return array<string, mixed>
	 */
	public static function sanitize( array $raw ): array {
		return array(
			'key'      => self::sanitize_key_string( (string) ( $raw['key'] ?? '' ), 'group' ),
			'title'    => sanitize_text_field( (string) ( $raw['title'] ?? '' ) ),
			'fields'   => self::sanitize_fields( $raw['fields'] ?? array() ),
			'location' => self::sanitize_location( $raw['location'] ?? array() ),
			'settings' => self::sanitize_settings( $raw['settings'] ?? array() ),
		);
	}

	/**
	 * Sanitize a list of field definitions, recursing into sub fields.
	 *
	 * @param mixed $raw   Untrusted field list.
	 * @param int   $depth Current nesting depth.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function sanitize_fields( $raw, int $depth = 0 ): array {
		if ( ! is_array( $raw ) || $depth > 10 ) {
			return array();
		}

		$fields = array();

		foreach ( $raw as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$name = self::sanitize_field_name( (string) ( $field['name'] ?? '' ) );
			$type = sanitize_key( (string) ( $field['type'] ?? 'text' ) );

			if ( '' === $name ) {
				continue;
			}

			$clean = array(
				'key'          => self::sanitize_key_string( (string) ( $field['key'] ?? '' ), 'field' ),
				'name'         => $name,
				'label'        => sanitize_text_field( (string) ( $field['label'] ?? '' ) ),
				'type'         => '' !== $type ? $type : 'text',
				'instructions' => wp_kses_post( (string) ( $field['instructions'] ?? '' ) ),
				'required'     => ! empty( $field['required'] ),
				'default'      => self::sanitize_scalar_or_list( $field['default'] ?? '' ),
				'placeholder'  => sanitize_text_field( (string) ( $field['placeholder'] ?? '' ) ),
				'wrapper'      => array(
					'width' => self::sanitize_width( $field['wrapper']['width'] ?? '' ),
					'class' => sanitize_html_class( (string) ( $field['wrapper']['class'] ?? '' ) ),
					'id'    => sanitize_html_class( (string) ( $field['wrapper']['id'] ?? '' ) ),
				),
				'settings'     => self::sanitize_type_settings( $field['settings'] ?? array() ),
				'conditional'  => self::sanitize_conditional( $field['conditional'] ?? array() ),
			);

			if ( isset( $field['sub_fields'] ) ) {
				$clean['sub_fields'] = self::sanitize_fields( $field['sub_fields'], $depth + 1 );
			}

			if ( isset( $field['layouts'] ) && is_array( $field['layouts'] ) ) {
				$clean['layouts'] = array();
				foreach ( $field['layouts'] as $layout ) {
					if ( ! is_array( $layout ) ) {
						continue;
					}
					// A layout is named explicitly, or named after its label.
					$layout_name = self::sanitize_field_name( (string) ( $layout['name'] ?? '' ) );

					if ( '' === $layout_name ) {
						$layout_name = self::sanitize_field_name( (string) ( $layout['label'] ?? '' ) );
					}

					// A layout with no usable name is dropped: rows record
					// their layout by name, and an unnamed layout could never
					// be matched back to its rows.
					if ( '' === $layout_name ) {
						continue;
					}

					$clean['layouts'][] = array(
						'key'        => self::sanitize_key_string( (string) ( $layout['key'] ?? '' ), 'layout' ),
						'name'       => $layout_name,
						'label'      => sanitize_text_field( (string) ( $layout['label'] ?? '' ) ),
						'settings'   => self::sanitize_type_settings( $layout['settings'] ?? array() ),
						'sub_fields' => self::sanitize_fields( $layout['sub_fields'] ?? array(), $depth + 1 ),
					);
				}
			}

			$fields[] = $clean;
		}

		return $fields;
	}

	/**
	 * Sanitize per-type settings.
	 *
	 * Field types own their settings, so values are sanitized generically
	 * rather than against a per-type schema: scalars are text, lists recurse
	 * one level. Field types re-cast what they read.
	 *
	 * @param mixed $raw Untrusted settings.
	 *
	 * @return array<string, mixed>
	 */
	private static function sanitize_type_settings( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$clean = array();

		foreach ( $raw as $key => $value ) {
			$key = sanitize_key( (string) $key );
			if ( '' === $key ) {
				continue;
			}
			$clean[ $key ] = self::sanitize_scalar_or_list( $value );
		}

		return $clean;
	}

	/**
	 * Sanitize a scalar, or a one-level list/map of scalars.
	 *
	 * @param mixed $value Untrusted value.
	 *
	 * @return string|bool|int|float|array<array-key, string|bool|int|float>
	 */
	private static function sanitize_scalar_or_list( $value ) {
		if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
			return $value;
		}

		if ( is_array( $value ) ) {
			$clean = array();
			foreach ( $value as $key => $item ) {
				if ( is_array( $item ) ) {
					continue;
				}
				$clean[ is_int( $key ) ? $key : sanitize_text_field( (string) $key ) ] =
					is_scalar( $item ) && ! is_string( $item ) ? $item : sanitize_textarea_field( (string) $item );
			}

			return $clean;
		}

		return sanitize_textarea_field( (string) $value );
	}

	/**
	 * Sanitize conditional logic rules.
	 *
	 * @param mixed $raw Untrusted conditional config.
	 *
	 * @return array<string, mixed>
	 */
	private static function sanitize_conditional( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$groups = array();

		foreach ( self::conditional_groups( $raw ) as $group ) {
			$rules = array();

			foreach ( (array) $group as $rule ) {
				if ( ! is_array( $rule ) || empty( $rule['field'] ) ) {
					continue;
				}

				$rules[] = array(
					'field'    => self::sanitize_key_string( (string) $rule['field'], 'field' ),
					'operator' => self::sanitize_operator( (string) ( $rule['operator'] ?? '==' ) ),
					'value'    => sanitize_text_field( (string) ( $rule['value'] ?? '' ) ),
				);
			}

			if ( array() !== $rules ) {
				$groups[] = $rules;
			}
		}

		if ( array() === $groups ) {
			return array();
		}

		return array(
			'action' => in_array( $raw['action'] ?? 'show', array( 'show', 'hide' ), true ) ? $raw['action'] : 'show',
			'groups' => $groups,
		);
	}

	/**
	 * Read conditional logic into an OR list of AND groups.
	 *
	 * Rule groups replaced a single list with one all/any switch, which could
	 * say "A and B" or "A or B" but never "A and B, or C" — and that is what
	 * most real conditions turn out to be. Location rules have been groups
	 * since the first release, so this is the same shape in the same place.
	 *
	 * The old form converts exactly rather than being discarded: `all` is one
	 * group holding every rule, `any` is one group per rule. Every stored
	 * field group keeps the behaviour it had, with no migration.
	 *
	 * @param array<string, mixed> $raw Untrusted conditional config.
	 *
	 * @return array<int, array<int, mixed>>
	 */
	private static function conditional_groups( array $raw ): array {
		return Conditional::groups( $raw );
	}

	/**
	 * Sanitize location rules.
	 *
	 * @param mixed $raw Untrusted location config.
	 *
	 * @return array<int, array<int, array{param: string, operator: string, value: string}>>
	 */
	private static function sanitize_location( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$groups = array();

		foreach ( $raw as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			$rules = array();

			foreach ( $group as $rule ) {
				if ( ! is_array( $rule ) ) {
					continue;
				}
				$param = sanitize_key( (string) ( $rule['param'] ?? '' ) );

				/*
				 * A parameter nobody offers right now is kept, not dropped.
				 * Every rule in a group has to match, so a rule that cannot
				 * match keeps its group off every screen — while removing it
				 * leaves the others to match more than they were meant to.
				 * "Product AND simple product", saved while the shop plugin
				 * was off, became every product.
				 */
				if ( '' === $param ) {
					continue;
				}
				$rules[] = array(
					'param'    => $param,
					'operator' => in_array( $rule['operator'] ?? '==', array( '==', '!=' ), true ) ? $rule['operator'] : '==',
					'value'    => sanitize_text_field( (string) ( $rule['value'] ?? '' ) ),
				);
			}

			if ( array() !== $rules ) {
				$groups[] = $rules;
			}
		}

		return $groups;
	}

	/**
	 * Sanitize display settings.
	 *
	 * @param mixed $raw Untrusted settings.
	 *
	 * @return array<string, mixed>
	 */
	private static function sanitize_settings( $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();

		$hide = array();
		if ( isset( $raw['hide_on_screen'] ) && is_array( $raw['hide_on_screen'] ) ) {
			$hide = array_values( array_filter( array_map( 'sanitize_key', $raw['hide_on_screen'] ) ) );
		}

		$supports = array();

		if ( isset( $raw['block_supports'] ) && is_array( $raw['block_supports'] ) ) {
			$supports = array_values(
				array_intersect(
					array_map( 'sanitize_key', $raw['block_supports'] ),
					array( 'align', 'anchor', 'custom_class_name', 'color', 'spacing', 'typography' )
				)
			);
		}

		return array(
			// Absent means active. Stored groups have this overwritten from
			// their post status; groups registered in code do not, and one
			// that defaulted to inactive would silently never appear.
			'active'                => (bool) ( $raw['active'] ?? true ),

			// Block settings. A group is a block only when it says so and
			// names itself: a block name is part of a site's saved content,
			// so it must be chosen deliberately rather than derived from a
			// title that someone may later rename.
			'block_enabled'         => ! empty( $raw['block_enabled'] ),
			'block_name'            => self::sanitize_field_name( (string) ( $raw['block_name'] ?? '' ) ),
			'block_icon'            => sanitize_text_field( (string) ( $raw['block_icon'] ?? '' ) ),
			// Same normalisation as a field name: "Layout Things" becomes
			// layout_things rather than layoutthings, which is what a person
			// typing a category with a space in it means.
			'block_category'        => self::sanitize_field_name( (string) ( $raw['block_category'] ?? '' ) ),
			'block_description'     => sanitize_text_field( (string) ( $raw['block_description'] ?? '' ) ),
			'block_keywords'        => sanitize_text_field( (string) ( $raw['block_keywords'] ?? '' ) ),
			'block_mode'            => self::one_of( $raw['block_mode'] ?? null, array( 'auto', 'preview', 'edit' ) ),
			'block_supports'        => $supports,
			'block_inner_blocks'    => ! empty( $raw['block_inner_blocks'] ),
			'position'              => self::one_of( $raw['position'] ?? null, array( 'normal', 'side', 'advanced' ) ),
			'style'                 => self::one_of( $raw['style'] ?? null, array( 'default', 'seamless' ) ),
			'label_placement'       => self::one_of( $raw['label_placement'] ?? null, array( 'top', 'left' ) ),
			'instruction_placement' => self::one_of( $raw['instruction_placement'] ?? null, array( 'field', 'label' ) ),
			'menu_order'            => (int) ( $raw['menu_order'] ?? 0 ),
			'description'           => sanitize_text_field( (string) ( $raw['description'] ?? '' ) ),
			'display_title'         => sanitize_text_field( (string) ( $raw['display_title'] ?? '' ) ),

			/*
			 * Absent means on: a group saved before this setting existed was
			 * exposed, and reading absence as off would silently drop its
			 * fields out of every REST response. The editor posts an explicit
			 * 0 from a hidden input, so an unchecked box is still off.
			 */
			'show_in_rest'          => ! isset( $raw['show_in_rest'] ) || ! empty( $raw['show_in_rest'] ),
			'hide_on_screen'        => $hide,

			/*
			 * A capability nobody holds would make the page unreachable, so an
			 * empty one falls back to the default rather than being honoured.
			 */
			'options_capability'    => '' !== (string) ( $raw['options_capability'] ?? '' )
				? sanitize_key( (string) $raw['options_capability'] )
				: 'manage_options',
			'options_icon'          => sanitize_text_field( (string) ( $raw['options_icon'] ?? '' ) ),

			/*
			 * `wpcmb` is this plugin's own menu. It is in the list because an
			 * options page built by the plugin belongs next to the field
			 * groups that built it as readily as it belongs under Settings.
			 */
			'options_parent'        => self::one_of(
				$raw['options_parent'] ?? null,
				array( '', 'wpcmb', 'options-general.php', 'tools.php', 'themes.php', 'edit.php', 'upload.php', 'users.php' )
			),
		);
	}

	/**
	 * Return the value if it is one of the allowed ones, else the first allowed.
	 *
	 * @param mixed             $value   Untrusted value.
	 * @param array<int,string> $allowed Allowed values, most-default first.
	 */
	private static function one_of( $value, array $allowed ): string {
		return is_string( $value ) && in_array( $value, $allowed, true ) ? $value : $allowed[0];
	}

	/**
	 * Reduce a label or typed name to a meta key.
	 *
	 * Whitespace and dashes become underscores before sanitize_key() drops
	 * them, so "First Name" becomes `first_name` rather than `firstname`.
	 * The builder's JavaScript applies the same rule; if the two disagree, a
	 * field is silently renamed on save and its stored values are orphaned.
	 *
	 * Leading underscores are stripped. A field name is written straight to
	 * `update_metadata()`, and an underscore is what WordPress and every
	 * plugin on the site use to mark meta as protected and internal — so a
	 * field named `_thumbnail_id` or `_edit_last` would hand everyone who can
	 * edit that object a writable path to a key that something else owns.
	 * Whoever creates the field needs `manage_options`, but whoever fills it
	 * in needs only `edit_post`, and that is the boundary this protects.
	 *
	 * A name of nothing but underscores reduces to an empty string, and
	 * sanitize_fields() drops a field with no name.
	 *
	 * @param string $name Untrusted name.
	 */
	public static function sanitize_field_name( string $name ): string {
		return ltrim( sanitize_key( (string) preg_replace( '/[\s\-]+/', '_', trim( $name ) ) ), '_' );
	}

	/**
	 * Sanitize a group/field/layout key, generating one when absent or malformed.
	 *
	 * @param string $key    Untrusted key.
	 * @param string $prefix Prefix to generate with.
	 */
	private static function sanitize_key_string( string $key, string $prefix ): string {
		$key = sanitize_key( $key );

		/*
		 * Underscores and hyphens are allowed after the prefix, not just the
		 * hex the editor generates. A key is an identity: a group keyed
		 * `group_site_header` in code, exported and imported, has to come back
		 * with that key — regenerating it renames the group, orphans its
		 * stored values, and makes the next import create a second copy
		 * instead of updating the first.
		 */
		return preg_match( '/^(group|field|layout)_[a-z0-9_-]+$/', $key ) ? $key : self::generate_key( $prefix );
	}

	/**
	 * Sanitize a conditional operator.
	 *
	 * @param string $operator Untrusted operator.
	 */
	private static function sanitize_operator( string $operator ): string {
		$allowed = array( '==', '!=', '>', '<', 'contains', 'not_contains', 'empty', 'not_empty', 'pattern' );

		return in_array( $operator, $allowed, true ) ? $operator : '==';
	}

	/**
	 * Sanitize a wrapper width percentage.
	 *
	 * @param mixed $width Untrusted width.
	 */
	private static function sanitize_width( $width ): string {
		$width = (int) $width;

		return $width > 0 && $width <= 100 ? (string) $width : '';
	}
}
