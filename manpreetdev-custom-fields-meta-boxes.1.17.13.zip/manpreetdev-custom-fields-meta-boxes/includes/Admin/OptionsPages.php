<?php
/**
 * Options pages, created from the location rules that ask for them.
 *
 * @package WPCMB
 */

declare( strict_types=1 );

namespace WPCMB\Admin;

use WPCMB\Abstracts\Module;
use WPCMB\Fields\Conditional;
use WPCMB\Fields\Context;
use WPCMB\Fields\FieldGroup;
use WPCMB\Fields\ObjectRef;
use WPCMB\Fields\Permissions;
use WPCMB\Fields\Renderer;
use WPCMB\Fields\Repository;
use WPCMB\Fields\Resolver;
use WPCMB\Fields\Validator;
use WPCMB\Fields\Values;
use WPCMB\PostTypes\CustomOptionsPages;

defined( 'ABSPATH' ) || exit;

/**
 * Turns "Options Page is site-settings" into an actual screen.
 *
 * The rule, the storage and the reading side all existed already: a group
 * could be located on an options page, values written against an `option`
 * reference were stored as prefixed options, and `wpcmb_get_field( 'name',
 * 'options_site-settings' )` read them back. The screen itself did not. So
 * choosing that rule produced a group that could never appear unless the site
 * registered a menu page and called the renderer itself — which is exactly
 * the code nobody should have to write in a theme.
 *
 * Every page here is discovered, never configured: the slug comes from the
 * rule, so there is no second list of pages to keep in step with the rules
 * that point at them. Delete the rule and the page goes with it.
 */
final class OptionsPages extends Module {

	/**
	 * Nonce action for saving a page.
	 */
	private const NONCE = 'wpcmb_save_options';

	/**
	 * Prefix for the admin page slug.
	 *
	 * The rule's value is the object id, not the menu slug: prefixing keeps a
	 * page called `general` or `tools` from colliding with a core screen or
	 * with another plugin that had the same idea.
	 */
	private const SLUG_PREFIX = 'wpcmb-options-';

	/**
	 * The last save's errors, read once per request.
	 *
	 * The notice and the fields both want them, and reading the transient
	 * twice would mean deleting it twice — so it is read once, deleted
	 * immediately, and kept here for whoever asks next.
	 *
	 * @var array<string, string>|null
	 */
	private ?array $result = null;

	/**
	 * Only load in the admin.
	 */
	public function is_enabled(): bool {
		return is_admin();
	}

	/**
	 * Register hooks.
	 */
	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register' ) );

		/*
		 * A page with a capability of its own has to be reachable by whoever
		 * holds it. Without this, lowering the capability would put the menu
		 * item in front of a user who is then refused at the door, because
		 * the default rule for an options object is manage_options.
		 */
		add_filter( 'wpcmb/permissions/read', array( $this, 'allow' ), 10, 2 );
		add_filter( 'wpcmb/permissions/edit', array( $this, 'allow' ), 10, 2 );
	}

	/**
	 * Judge an options object by its own page's capability.
	 *
	 * @param bool  $allowed Decision so far.
	 * @param mixed $ref     Object being judged.
	 */
	public function allow( $allowed, $ref ): bool {
		if ( ! $ref instanceof ObjectRef || ObjectRef::OPTION !== $ref->type ) {
			return (bool) $allowed;
		}

		$page = $this->pages()[ (string) $ref->id ] ?? null;

		// Not one of ours: an options object can come from anywhere, and the
		// default rule is the right answer for the ones we did not create.
		if ( null === $page ) {
			return (bool) $allowed;
		}

		return current_user_can( '' !== (string) ( $page['capability'] ?? '' ) ? (string) $page['capability'] : 'manage_options' );
	}

	/**
	 * The options pages the location rules ask for.
	 *
	 * Only `==` rules name a page. A rule saying the group is *not* on some
	 * options page describes where it does not go, which is no reason to
	 * build anything.
	 *
	 * @return array<string, array{title: string, order: int, capability?: string, icon?: string, parent?: string}>
	 */
	public function pages(): array {
		$pages = array();

		foreach ( $this->container->get( Repository::class )->all() as $group ) {
			foreach ( $this->slugs_in( $group ) as $slug ) {
				$order = (int) ( $group->settings['menu_order'] ?? 0 );

				// Two groups can share a page. The first one, in the order the
				// list itself is sorted, names it.
				if ( isset( $pages[ $slug ] ) && $pages[ $slug ]['order'] <= $order ) {
					continue;
				}

				$pages[ $slug ] = array(
					'title'      => '' !== $group->title ? $group->title : $this->humanise( $slug ),
					'order'      => $order,

					// The group that names the page also decides who may open
					// it and where it sits. A second group sharing the page
					// contributes its fields, not its menu.
					'capability' => (string) ( $group->settings['options_capability'] ?? 'manage_options' ),
					'icon'       => (string) ( $group->settings['options_icon'] ?? '' ),
					'parent'     => (string) ( $group->settings['options_parent'] ?? '' ),
				);
			}
		}

		/*
		 * Records override rules.
		 *
		 * A page described on the Options Pages screen has settings a rule
		 * cannot express — a page title of its own, a position, a parent that
		 * is another options page — so where both exist for one slug, the
		 * record is the description and the rule is left to do what it still
		 * does well: decide which groups appear on the page.
		 */
		$pages = array_merge( $pages, $this->container->get( CustomOptionsPages::class )->pages() );

		ksort( $pages );

		/**
		 * Filters the options pages discovered from location rules.
		 *
		 * Adding an entry here creates a page with no rule pointing at it,
		 * which is how a site can build one in code and still have the
		 * plugin render and save it.
		 *
		 * @since 1.3.0
		 *
		 * @param array<string, array{title: string, order: int, capability?: string, icon?: string, parent?: string}> $pages Keyed by slug.
		 */
		return (array) apply_filters( 'wpcmb/options_pages', $pages );
	}

	/**
	 * The options page slugs one group's rules name.
	 *
	 * @param FieldGroup $group Field group.
	 *
	 * @return array<int, string>
	 */
	private function slugs_in( FieldGroup $group ): array {
		$slugs = array();

		foreach ( $group->location as $rule_group ) {
			foreach ( (array) $rule_group as $rule ) {
				if ( ! is_array( $rule ) || 'options_page' !== ( $rule['param'] ?? '' ) ) {
					continue;
				}

				if ( '==' !== ( $rule['operator'] ?? '==' ) ) {
					continue;
				}

				// Sanitized the same way ObjectRef does, so the menu slug and
				// the object the values are stored against cannot drift.
				$slug = sanitize_key( (string) ( $rule['value'] ?? '' ) );

				if ( '' !== $slug ) {
					$slugs[ $slug ] = $slug;
				}
			}
		}

		return array_values( $slugs );
	}

	/**
	 * Add a menu entry for each discovered page.
	 *
	 * Top level, in the main menu, because that is where an options page an
	 * editor uses every day belongs — not three clicks deep under Settings.
	 * Set `parent` through `wpcmb/options_page/args` to move one.
	 *
	 * Both names carry the slug, and the page title carries the plugin's name
	 * as well: a site can have several of these, they are created from
	 * whatever somebody typed into a rule, and "Site Options" alone tells you
	 * neither which plugin made it nor which slug it stores against.
	 */
	public function register(): void {
		// Core puts Settings at 80, so this sits immediately below it: an
		// options screen reads as a settings screen, and that is where
		// somebody looking for one will look.
		$position = 80.9;
		$pages    = $this->pages();

		/*
		 * The options page a page sits under, if it sits under one of these.
		 * The editor stores the parent's menu slug, wpcmb-options-{slug}; a
		 * page defined in code may name the bare slug. Either way it is one
		 * of ours, and the answer is its slug.
		 */
		$own_parent = static function ( array $page ) use ( &$pages ): string {
			$parent = (string) ( $page['parent'] ?? '' );
			$bare   = str_starts_with( $parent, self::SLUG_PREFIX ) ? substr( $parent, strlen( self::SLUG_PREFIX ) ) : $parent;

			return '' !== $bare && isset( $pages[ $bare ] ) ? $bare : '';
		};

		/*
		 * Parents first. WordPress lists a top-level page as the first entry
		 * under itself only if it is in the menu before its first sub-page
		 * is added; added in slug order, a sub-page whose slug sorts first —
		 * "about" under "site" — came first, and the parent's own link then
		 * led to the sub-page with no way back to the parent.
		 */
		$is_child = static fn( array $page ): bool => '' !== $own_parent( $page );

		uasort( $pages, static fn( array $a, array $b ): int => (int) $is_child( $a ) <=> (int) $is_child( $b ) );

		foreach ( $pages as $slug => $page ) {
			$parent = (string) ( $page['parent'] ?? '' );
			$owner  = $own_parent( $page );

			// WordPress lists the parent first under itself, as long as it is
			// already in the menu: which is why parents are added first.
			if ( '' !== $owner ) {
				$parent = self::SLUG_PREFIX . $owner;
			}

			$args = array(
				// An empty parent still means a top-level menu; the filter
				// below takes null for the same thing, which is what it has
				// always taken.
				'parent'     => '' !== $parent ? $parent : null,

				/*
				 * A record can name the page title outright. The generated one
				 * says which plugin made the page and which slug it stores
				 * against, which is the right default for a page that appeared
				 * because of a rule and the wrong one for a page somebody sat
				 * down and named.
				 */
				'page_title' => '' !== (string) ( $page['page_title'] ?? '' )
					? (string) $page['page_title']
					: sprintf(
						/* translators: 1: plugin name, 2: page title, 3: options page slug. */
						__( '%1$s: %2$s (%3$s)', 'manpreetdev-custom-fields-meta-boxes' ),
						self::plugin_name(),
						$page['title'],
						$slug
					),
				'menu_title' => self::menu_label( $page['title'], $slug ),
				'capability' => '' !== (string) ( $page['capability'] ?? '' ) ? (string) $page['capability'] : 'manage_options',
				'icon'       => '' !== (string) ( $page['icon'] ?? '' ) ? (string) $page['icon'] : 'dashicons-admin-generic',

				// Fractional, so several of these keep their order among
				// themselves without displacing anything already at 81.
				'position'   => $position,
			);

			$position += 0.01;

			/**
			 * Filters how one options page is added to the admin menu.
			 *
			 * Set `parent` to a menu file to move it — `null` makes it a
			 * top-level menu of its own.
			 *
			 * @since 1.3.0
			 *
			 * @param array<string, mixed> $args Menu arguments.
			 * @param string               $slug Options page slug.
			 */
			$args = (array) apply_filters( 'wpcmb/options_page/args', $args, $slug );

			$render = function () use ( $slug ): void {
				$this->render( $slug );
			};

			$hook = null === ( $args['parent'] ?? null )
				? add_menu_page(
					(string) $args['page_title'],
					(string) $args['menu_title'],
					(string) $args['capability'],
					self::SLUG_PREFIX . $slug,
					$render,
					(string) $args['icon'],
					null === $args['position'] ? null : (float) $args['position']
				)
				: add_submenu_page(
					(string) $args['parent'],
					(string) $args['page_title'],
					(string) $args['menu_title'],
					(string) $args['capability'],
					self::SLUG_PREFIX . $slug,
					$render,
					null === $args['position'] ? null : (int) $args['position']
				);

			if ( ! is_string( $hook ) || '' === $hook ) {
				continue;
			}

			// Saving happens on `load-`, before anything is sent, so a
			// successful save can redirect and a refresh cannot repeat it.
			add_action(
				'load-' . $hook,
				function () use ( $slug ): void {
					$this->handle_save( $slug );
				}
			);
		}
	}

	/**
	 * Store a submitted page, then send the browser back to it.
	 *
	 * @param string $slug Options page slug.
	 */
	private function handle_save( string $slug ): void {
		if ( ! isset( $_POST['wpcmb_options_nonce'] ) ) {
			return;
		}

		check_admin_referer( self::NONCE, 'wpcmb_options_nonce' );

		$ref = new ObjectRef( ObjectRef::OPTION, $slug );

		if ( ! Permissions::can_edit( $ref ) ) {
			wp_die( esc_html__( 'You do not have permission to edit these options.', 'manpreetdev-custom-fields-meta-boxes' ) );
		}

		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cleaned on receipt by wpcmb_clean_input() (includes/API/functions.php), then each value is sanitized by its own field type before any hook sees it or it is stored. A text sanitizer cannot be used here: rich text, HTML and code fields hold markup on purpose.
		$submitted = isset( $_POST[ Renderer::INPUT_PREFIX ] ) && is_array( $_POST[ Renderer::INPUT_PREFIX ] )
			? wpcmb_clean_input( wp_unslash( $_POST[ Renderer::INPUT_PREFIX ] ) )
			: array();
		// phpcs:enable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		$renderer = $this->container->get( Renderer::class );
		$values   = $this->container->get( Values::class );
		$fields   = array();
		$present  = array();

		/*
		 * Every field on the page is written, including the ones the request
		 * left out. This is the opposite of the meta box save path, which
		 * skips absent fields so a partial submission cannot wipe what it
		 * never showed — but this form always carries every field, so absent
		 * means emptied. Without it a checkbox could be ticked and never
		 * unticked again.
		 */
		foreach ( $this->container->get( Resolver::class )->fields( new Context( $ref ) ) as $name => $field ) {
			if ( ! $renderer->stores_value( $field ) ) {
				continue;
			}

			$fields[ $name ]  = $field;
			$present[ $name ] = $submitted[ $name ] ?? null;
		}

		/*
		 * A field hidden by conditional logic was not on the form, so a value
		 * posted for it was added to the request. The same guard the edit
		 * screen and the front-end form apply; this page needs it for the same
		 * reason, and a dropped field keeps what it had rather than being
		 * emptied by a submission that never showed it.
		 */
		$present = Conditional::visible_values( $fields, $present );

		$errors = $this->container->get( Validator::class )->validate( $fields, $present );
		$clean  = array();

		foreach ( $present as $name => $value ) {
			$clean[ $name ] = $renderer->sanitize( $value, $fields[ $name ] );

			$values->update( $name, $clean[ $name ], $ref );
		}

		/**
		 * Fires after an options page has been saved.
		 *
		 * Handed the sanitized values, not the request. An extension reading
		 * this is reading plugin data and should not have to sanitize it
		 * again — and would not reliably know to.
		 *
		 * @since 1.3.0
		 *
		 * @param string                $slug   Options page slug.
		 * @param array<string, mixed>  $clean  Sanitized values that were stored.
		 * @param array<string, string> $errors Validation errors, if any.
		 */
		do_action( 'wpcmb/options_page/saved', $slug, $clean, $errors );

		set_transient( $this->result_key( $slug ), $errors, MINUTE_IN_SECONDS * 5 );

		wp_safe_redirect(
			add_query_arg(
				'wpcmb-saved',
				array() === $errors ? '1' : '0',
				menu_page_url( self::SLUG_PREFIX . $slug, false )
			)
		);

		exit;
	}

	/**
	 * Render one options page.
	 *
	 * @param string $slug Options page slug.
	 */
	private function render( string $slug ): void {
		$ref = new ObjectRef( ObjectRef::OPTION, $slug );

		if ( ! Permissions::can_edit( $ref ) ) {
			wp_die( esc_html__( 'You do not have permission to view these options.', 'manpreetdev-custom-fields-meta-boxes' ) );
		}

		$pages = $this->pages();

		// The page's own title when it has one: that is what the setting is
		// for. The menu title is only the fallback.
		$title = '' !== (string) ( $pages[ $slug ]['page_title'] ?? '' )
			? (string) $pages[ $slug ]['page_title']
			: (string) ( $pages[ $slug ]['title'] ?? $this->humanise( $slug ) );

		$groups   = $this->container->get( Resolver::class )->groups( new Context( $ref ) );
		$renderer = $this->container->get( Renderer::class );

		$this->render_notice( $slug );
		?>
		<div class="wrap wpcmb-wrap">
			<span class="wpcmb-eyebrow wpcmb-options-eyebrow"><?php echo esc_html( self::plugin_name() ); ?></span>
			<h1>
				<?php echo esc_html( $title ); ?>
				<code class="wpcmb-options-slug" title="<?php esc_attr_e( 'The options page slug these values are stored against', 'manpreetdev-custom-fields-meta-boxes' ); ?>"><?php echo esc_html( $slug ); ?></code>
			</h1>

			<?php if ( array() === $groups ) : ?>
				<div class="wpcmb-empty wpcmb-empty--page">
					<span class="wpcmb-empty__title"><?php esc_html_e( 'No fields here yet', 'manpreetdev-custom-fields-meta-boxes' ); ?></span>
					<p>
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: options page slug. */
								__( 'Add fields to a group whose location is "Options Page is %s" and they will appear here.', 'manpreetdev-custom-fields-meta-boxes' ),
								$slug
							)
						);
						?>
					</p>
				</div>
			<?php else : ?>
				<form method="post" action="<?php echo esc_url( menu_page_url( self::SLUG_PREFIX . $slug, false ) ); ?>">
					<?php
					wp_nonce_field( self::NONCE, 'wpcmb_options_nonce' );

					$renderer->set_errors( $this->take_errors( $slug ) );

					foreach ( $groups as $group ) {
						echo '<section class="wpcmb-card wpcmb-options-group">';

						if ( '' !== $group->title && count( $groups ) > 1 ) {
							printf( '<h2>%s</h2>', esc_html( $group->title ) );
						}

						$renderer->group( $group, $ref );

						echo '</section>';
					}
					?>

					<p class="wpcmb-options-actions">
						<button type="submit" class="wpcmb-btn wpcmb-btn--primary wpcmb-btn--lg">
							<?php esc_html_e( 'Save options', 'manpreetdev-custom-fields-meta-boxes' ); ?>
						</button>
					</p>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Report the outcome of the last save.
	 *
	 * @param string $slug Options page slug.
	 */
	private function render_notice( string $slug ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only result flag; the save itself verified its nonce.
		$saved = isset( $_GET['wpcmb-saved'] ) ? sanitize_key( wp_unslash( $_GET['wpcmb-saved'] ) ) : '';

		if ( '' === $saved ) {
			return;
		}

		/*
		 * Which it was is decided by the flag the save set, not by whether
		 * any errors are still to hand: they are consumed when they are
		 * shown, and a refresh of a failed save must not then congratulate
		 * anybody on a save that did not go through cleanly.
		 */
		if ( '1' === $saved ) {
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
				esc_html__( 'Options saved.', 'manpreetdev-custom-fields-meta-boxes' )
			);

			return;
		}

		$errors = $this->take_errors( $slug );

		if ( array() === $errors ) {
			printf(
				'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
				esc_html__( 'Your options were saved, but some fields needed attention.', 'manpreetdev-custom-fields-meta-boxes' )
			);

			return;
		}

		printf(
			'<div class="notice notice-warning"><p><strong>%s</strong></p><ul class="wpcmb-error-list">',
			esc_html__( 'Your options were saved, but some fields need attention:', 'manpreetdev-custom-fields-meta-boxes' )
		);

		foreach ( $errors as $message ) {
			printf( '<li>%s</li>', esc_html( $message ) );
		}

		echo '</ul></div>';
	}

	/**
	 * The errors from the last save, read once and then gone.
	 *
	 * They belong to the save that produced them and to the screen that
	 * save redirected to. Left in place they went on marking the fields
	 * red for five minutes, so anybody opening the page afterwards met a
	 * screenful of errors about values they had not touched, with no
	 * notice to explain them.
	 *
	 * @param string $slug Options page slug.
	 *
	 * @return array<string, string>
	 */
	private function take_errors( string $slug ): array {
		if ( null !== $this->result ) {
			return $this->result;
		}

		$errors = get_transient( $this->result_key( $slug ) );

		delete_transient( $this->result_key( $slug ) );

		$this->result = is_array( $errors ) ? $errors : array();

		return $this->result;
	}

	/**
	 * The transient key holding one user's last result for a page.
	 *
	 * @param string $slug Options page slug.
	 */
	private function result_key( string $slug ): string {
		return 'wpcmb_options_result_' . get_current_user_id() . '_' . $slug;
	}

	/**
	 * The two-line label for one page in the admin menu.
	 *
	 * The name on one line and the slug under it. On a single line the two run
	 * together and the sidebar breaks the slug mid-word, which reads as a typo
	 * rather than as a name.
	 *
	 * WordPress prints a menu title as markup — that is how core's own update
	 * bubbles work — so the second line is a span. It is styled inline because
	 * the admin menu is on every screen in wp-admin while this plugin's
	 * stylesheet is deliberately only on its own; one label is not worth a
	 * stylesheet loaded everywhere.
	 *
	 * @param string $title Page title.
	 * @param string $slug  Options page slug.
	 */
	private static function menu_label( string $title, string $slug ): string {
		return sprintf(
			'%1$s<span style="display:block;font-size:11px;font-weight:400;line-height:1.5;opacity:0.65">(%2$s)</span>',
			esc_html( $title ),
			esc_html( $slug )
		);
	}

	/**
	 * The plugin's name, as WordPress knows it.
	 *
	 * Read from the plugin header so it cannot drift from what the Plugins
	 * screen says, and falls back to the menu's own wording when the header
	 * cannot be read — which is the case on a front-end request, where
	 * `get_plugin_data()` is not loaded.
	 */
	private static function plugin_name(): string {
		static $name = null;

		if ( null !== $name ) {
			return $name;
		}

		$name = __( 'Meta Boxes', 'manpreetdev-custom-fields-meta-boxes' );

		if ( ! function_exists( 'get_plugin_data' ) ) {
			return $name;
		}

		$data = get_plugin_data( WPCMB_DIR . 'manpreetdev-custom-fields-meta-boxes.php', false, false );

		if ( '' !== (string) ( $data['Name'] ?? '' ) ) {
			$name = (string) $data['Name'];
		}

		return $name;
	}

	/**
	 * A readable title for a slug that no group gave one to.
	 *
	 * @param string $slug Options page slug.
	 */
	private function humanise( string $slug ): string {
		return ucwords( str_replace( array( '-', '_' ), ' ', $slug ) );
	}

	/**
	 * The options page the current screen is, if it is one.
	 *
	 * Used by the asset loader, which has to know that a plugin screen can
	 * hold fields — without it the field styles and the save gate never load
	 * here and the page renders unstyled controls that nothing validates.
	 */
	public static function current_slug(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading which screen is being shown, not acting on it.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		return str_starts_with( $page, self::SLUG_PREFIX )
			? substr( $page, strlen( self::SLUG_PREFIX ) )
			: '';
	}
}
